#include <iostream>
#include <fstream>
#include <vector>
#include <ctime>
#include <cstdlib>

using namespace std;

const int NOT_SATISFIED = 1;
const int PARTIALLY_SATISFIED = 2;
const int SATISFIED = 3;
const int FULLY_SATISFIED = 4;

int countLinesInFile(const string& filename)
{
    ifstream file(filename);
    int count = 0;

    if (file.is_open())
    {
        string line;
        while (getline(file, line))
        {
            ++count;
        }

        file.close();
    }
    else
    {
        cerr << "Unable to open file: " << filename << endl;
    }

    return count;
}

void displayFileContent(const string& filename)
{
    ifstream inputFile(filename);

    if (!inputFile.is_open())
    {
        cerr << "Error opening the file: " << filename << endl;
        return;
    }

    string line;
    while (getline(inputFile, line))
    {
        cout << line << endl;
    }

    inputFile.close();
}


string recommendRandomRecipe(const string& filename, int numRecipes)
{
    if (numRecipes == 0)
    {
        return "No recipes available.";
    }

    srand(static_cast<unsigned int>(time(nullptr)));
    int randomIndex = rand() % numRecipes;

    ifstream file(filename);
    string recommendedRecipe;

    if (file.is_open())
    {
        for (int i = 0; i <= randomIndex; ++i)
        {
            getline(file, recommendedRecipe);
        }

        file.close();
    }
    else
    {
        cerr << "Unable to open file: " << filename << endl;
    }

    return recommendedRecipe;
}

void getFeedback(int& feedback)
{
    cout << "Please give Feedback on the recommended dish:" << endl
         << "1. not satisfied" << endl
         << "2. partially satisfied" << endl
         << "3. Satisfied" << endl
         << "4. Fully satisfied" << endl;
    cin >> feedback;

    while (feedback < NOT_SATISFIED || feedback > FULLY_SATISFIED)
    {
        cout << "Please enter a valid feedback option (1-4): ";
        cin >> feedback;
    }
    cout << "=========================================================================" << endl;

    cout << "Thank you for providing us feedback." << endl;
    cout << "=========================================================================" << endl;
}

void displayRecipe(const string& filename, const string& dishName)
{
    ifstream file(filename);
    string recipe;

    if (file.is_open())
    {
        while (getline(file, recipe))
        {
            if (recipe.find(dishName) != string::npos)
            {
                cout << "Recipe for " << dishName << ":\n";
                displayFileContent("recipe" + recipe.substr(0, recipe.find_first_of('.')) + ".txt");
                return;
            }
        }

        file.close();
    }
    else
    {
        cerr << "Unable to open file: " << filename << endl;
    }

    cout << "Recipe not found for " << dishName << "." << endl;
}

void playQuiz()
{
    cout << "Great! Let's start the quiz.\n";
    srand(time(0));

    char playAgain;

    do
    {
        cout << "==================================================================================================" << endl;
        vector<pair<string, string>> quizzes = {
            {"PaniPuri", "This dish has hollow shells and is a popular street food."},
            {"Pizza", "This dish is a favorite for delivery and is round and flat."},
            {"Samosa", "This Indian snack has a triangular shape and is often filled with spicy potatoes."},
            {"IdliDosa", "These South Indian dishes are made with rice and are commonly eaten for breakfast."},
            {"BhelPuri", "This Indian street food is a savory snack made with puffed rice, vegetables, and chutneys."}
        };

        int count = 0;

        for (const auto& quiz : quizzes)
        {
            string targetDish = quiz.first;
            string hint = quiz.second;
            int attempts = 0;

            do
            {
                string userGuess;

                cout << "Hint: " << hint << endl;
                cout << "Guess the name of the dish: ";
                cin >> userGuess;

                if (userGuess == targetDish)
                {
                    cout << "Congratulations! You guessed the correct dish name!" << endl;
                    count++;
                    break;
                }
                else
                {
                    cout << "Sorry, incorrect guess. Please try again." << endl;
                    attempts++;
                }

                if (attempts == 3)
                {
                    cout << "Sorry, you've reached the maximum number of attempts. The correct dish name was " << targetDish << "." << endl;
                    break;
                }
            } while (true);
        }

        cout << "TOTAL SCORE: " << count << "/" << quizzes.size() << endl;

        cout << "Do you want to play again? (y/n): ";
        cin >> playAgain;

    } while (playAgain == 'y' || playAgain == 'Y');
}

int main()
{
    string filename;
    int feedback;
    string dishname;
    int choice;
    int i;
    cout << "=========================================================================" << endl;
    cout << "Welcome to the Food Recommendation System!\n";
    cout << "=========================================================================" << endl;

    cout << "Choose an option:\n";
    cout << "1. Recipe Recommendation\n";
    cout << "2. Play a Quiz\n";
    cout << "3. Display a Specific Recipe\n";
    cout << "=========================================================================" << endl;

    int option;
    cin >> option;

    if (option == 1)
    {
        cout << "Which type of food would you like to eat:" << endl
             << "1. Chinese" << endl
             << "2. Korean" << endl
             << "3. Indian" << endl;
        cout << "=========================================================================" << endl;

        int type;
        cin >> type;
        int choice;
        int i;

        if (type == 1)
        {
            cout << "What you want: \n1. Spicy\n2. Sweet\n";
            cin >> choice;
            if (choice == 1)
            {
                cout<<"which ingredient you like:"<<endl<<"1.Rice"<<endl<<"2.Paneer"<<endl<<"noodles"<<endl;
                cin>>i;
                if(i==1)
                {
                    filename = "Crice.txt";
                }
                else if(i==2)
                {
                    filename = "CPaneer.txt";
                }
                else if(i==3)
                {
                    filename = "Cnoodles.txt";

                }
                else{
                    cout<<"invalid";
                }
            }
            else if (choice == 2)
            {
                cout<<"which type of sweet you would like: "<<endl<<"1.Dessert"<<"2.RIce"<<endl<<"3.Bakery";
                cin>>i;
                if(i==1)
                {
                    filename="SCdessert";
                }
                else if(i==2)
                {
                    filename="SCrice.txt";
                }
                else if(i==3)
                {
                    filename="SCbakery";
                }
                else{
                    cout<<"invalid";
                }

            }
            else
            {
                cerr << "Invalid choice" << endl;
                return 1;
            }
        }
        else if (type == 2)
        {
            cout << "What you want: \n1. Spicy\n2. Sweet\n";
            cin >> choice;
            if (choice == 1)
            {
                cout<<"which ingredient you like:"<<endl<<"1.Rice"<<endl<<"2.Paneer"<<endl<<"noodles"<<endl;
                cin>>i;
                if(i==1)
                {
                    filename = "Krice.txt";
                }
                else if(i==2)
                {
                    filename = "KPaneer.txt";
                }
                else if(i==3)
                {
                    filename = "Knoodles.txt";

                }
                else{
                    cout<<"invalid";
                }
            }
            else if(choice==2)
            {
                cout<<"which type of sweet you would like: "<<endl<<"1.Dessert"<<"2.RIce"<<endl<<"3.Bakery";
                cin>>i;
                if(i==1)
                {
                    filename="KCdessert";
                }
                else if(i==2)
                {
                    filename="KCrice.txt";
                }
                else if(i==3)
                {
                    filename="KCbakery";
                }
                else{
                    cout<<"invalid";
                }
            }
            else{
                cout<<"invalid";
            }
        }
        else if (type == 3)
        {
            cout << "What you want: \n1. Spicy\n2. Sweet\n";
            cin >> choice;
            if (choice == 1)
            {
                cout<<"which ingredient you like:"<<endl<<"1.Rice"<<endl<<"2.Paneer"<<endl<<"noodles"<<endl;
                cin>>i;
                if(i==1)
                {
                    filename = "Irice.txt";
                }
                else if(i==2)
                {
                    filename = "IPaneer.txt";
                }
                else if(i==3)
                {
                    filename = "Inoodles.txt";

                }
                else{
                    cout<<"invalid";
                }
            }
            else if(choice==2)
            {
                cout<<"which type of sweet you would like: "<<endl<<"1.Dessert"<<"2.RIce"<<endl<<"3.Bakery";
                cin>>i;
                if(i==1)
                {
                    filename="KCdessert";
                }
                else if(i==2)
                {
                    filename="KCrice.txt";
                }
                else if(i==3)
                {
                    filename="KCbakery";
                }
                else{
                    cout<<"invalid";
                }
            }
            else{
                cout<<"invalid";
            }
        }
        else
        {
            cerr << "Invalid inputs" << endl;
            return 1;
        }

        int numRecipes = countLinesInFile(filename);
        string recommendedRecipe = recommendRandomRecipe(filename, numRecipes);

        cout << "Recommended Recipe: " << recommendedRecipe << endl;
        cout << "=========================================================================" << endl;

        getFeedback(feedback);
    }
    else if (option == 2)
    {
        playQuiz();
        getFeedback(feedback);
    }
    else if (option == 3)
    {
        cout << "Which type of food would you like to eat:" << endl
             << "1. Chinese" << endl
             << "2. Korean" << endl
             << "3. Indian" << endl;
        cout << "=========================================================================" << endl;

        int type;
        cin >> type;
        int dish;

        if (type == 1)
        {
            cout << "What you want: \n1. Spicy\n2. Sweet\n";
            cin >> choice;
            if (choice == 1)
            {
                cout<<"which ingredient you like:"<<endl<<"1.Rice"<<endl<<"2.Paneer"<<endl<<"3.noodles"<<endl;
                cin>>i;
                if(i==1)
                {
                    filename = "Crice.txt";
                    displayFileContent("Crice.txt");
                   cout << "which dish would you like to eat..." << endl;
                    cout << "=========================================== ==============================" << endl;

                    cin >> dish;
                    if (dish == 1)
                    {
                        displayFileContent("crice1.txt");
                    }
                    else if (dish == 2)
                    {
                        displayFileContent("crice2.txt");
                    }
                    else if (dish == 3)
                    {
                        displayFileContent("crice3.txt");
                    }
                    else if (dish == 4)
                    {
                        displayFileContent("crice4.txt");
                    }
                    else if(dish==5)
                    {
                        displayFileContent("crice5.txt");
                    }
                    else{
                        cout<<"invalid input"<<endl;
                    }
                }
                else if(i==2)
                {
                    filename = "CPaneer.txt";
                    displayFileContent("CPaneer.txt");
                    cout << "which dish would you like to eat..." << endl;
                    cout << "=========================================== ==============================" << endl;
                    if (dish == 1)
                    {
                        displayFileContent("cPaneer1.txt");
                    }
                    else if (dish == 2)
                    {
                        displayFileContent("cPaneer2.txt");
                    }
                    else if (dish == 3)
                    {
                        displayFileContent("cPaneer3.txt");
                    }
                    else if (dish == 4)
                    {
                        displayFileContent("cPaneer4.txt");
                    }
                    else
                    {
                        displayFileContent("cPaneer5.txt");
                    }
                }
                else if(i==3)
                {
                    filename = "Cnoodles.txt";
                    displayFileContent("Cnoodles.txt");
                    cout << "which dish would you like to eat..." << endl;
                    cin >> dish;
                    cout << "=========================================== ==============================" << endl;

                    if (dish == 1)
                    {
                        displayFileContent("cnoodles1.txt");
                    }
                    else if (dish == 2)
                    {
                        displayFileContent("cnoodles2.txt");
                    }
                    else if (dish == 3)
                    {
                        displayFileContent("cnoodles3.txt");
                    }
                    else if (dish == 4)
                    {
                        displayFileContent("cnoodles4.txt");
                    }
                    else if(dish==5)
                    {
                        displayFileContent("cnoodles5.txt");
                    }
                    else{
                        cout<<"invalid"<<endl;
                    }               
                }
                else
                {
                    cout<<"invalid";
                } 
            }
            else if(choice==2)
            {
                cout<<"which type of sweet you would like: "<<endl<<"1.Dessert"<<endl<<"2.Rice"<<endl<<"3.Bakery";
                cin>>i;
                if(i==1)
                {
                    displayFileContent("Cdessert.txt");
                    cout << "which dish would you like to eat..." << endl;
                    cin >> dish;
                    cout << "=========================================== ==============================" << endl;
                    if (dish == 1)
                    {
                        displayFileContent("cdessert1.txt");
                    }
                    else if (dish == 2)
                    {
                        displayFileContent("cdessert2.txt");
                    }
                    else if (dish == 3)
                    {
                        displayFileContent("cdessert3.txt");
                    }
                    else if (dish == 4)
                    {
                        displayFileContent("cdessert4.txt");
                    }
                    else if(dish==5)
                    {
                        displayFileContent("cdessert5.txt");
                    }
                    else
                    {
                        cout<<"invalid"<<endl;
                    }               

                }
                else if(i==2)
                {
                    displayFileContent("Csrice.txt");
                    cout << "which dish would you like to eat..." << endl;
                    cin >> dish ;
                    cout << "=========================================== ==============================" << endl;
                    if (dish == 1)
                    {
                        displayFileContent("csrice1.txt");
                    }
                    else if (dish == 2)
                    {
                        displayFileContent("csrice2.txt");
                    }
                    else if (dish == 3)
                    {
                        displayFileContent("csrice3.txt");
                    }
                    else if (dish == 4)
                    {
                        displayFileContent("csrice4.txt");
                    }
                    else if(dish==5)
                    {
                        displayFileContent("csrice5.txt");
                    }
                    else
                    {
                        cout<<"invalid"<<endl;
                    }               

                }
                else if(i==3)
                {
                    displayFileContent("Cbakery.txt");
                    cout << "which dish would you like to eat..." << endl;
                    cout << "=========================================== ==============================" << endl;
                    if (dish == 1)
                    {
                        displayFileContent("cbakery1.txt");
                    }
                    else if (dish == 2)
                    {
                        displayFileContent("cbakery2.txt");
                    }
                    else if (dish == 3)
                    {
                        displayFileContent("cbakery3.txt");
                    }
                    else if (dish == 4)
                    {
                        displayFileContent("cbakery4.txt");
                    }
                    else if(dish==5)
                    {
                        displayFileContent("cbakery5.txt");
                    }
                    else
                    {
                        cout<<"invalid"<<endl;
                    }               
                }
                else
                {
                    cout<<"invalid";
                }
            }
               
        }
        else if (type == 2)
        {
            cout << "What you want: \n1. Spicy\n2. Sweet\n";
            cin >> choice;
            if (choice == 1)
            {
                cout<<"which ingredient you like:"<<endl<<"1.Rice"<<endl<<"2.Paneer"<<endl<<"3.noodles"<<endl;
                cin>>i;
                if(i==1)
                {
                    filename = "krice.txt";
                    displayFileContent("krice.txt");
                   cout << "which dish would you like to eat..." << endl;
                    cout << "=========================================== ==============================" << endl;

                    cin >> dish;
                    if (dish == 1)
                    {
                        displayFileContent("krice1.txt");
                    }
                    else if (dish == 2)
                    {
                        displayFileContent("krice2.txt");
                    }
                    else if (dish == 3)
                    {
                        displayFileContent("krice3.txt");
                    }
                    else if (dish == 4)
                    {
                        displayFileContent("krice4.txt");
                    }
                    else if(dish==5)
                    {
                        displayFileContent("krice5.txt");
                    }
                    else{
                        cout<<"invalid input"<<endl;
                    }
                }
                else if(i==2)
                {
                    filename = "kPaneer.txt";
                    displayFileContent("CPaneer.txt");
                    cout << "which dish would you like to eat..." << endl;
                    cout << "=========================================== ==============================" << endl;
                    if (dish == 1)
                    {
                        displayFileContent("kPaneer1.txt");
                    }
                    else if (dish == 2)
                    {
                        displayFileContent("kPaneer2.txt");
                    }
                    else if (dish == 3)
                    {
                        displayFileContent("kPaneer3.txt");
                    }
                    else if (dish == 4)
                    {
                        displayFileContent("kPaneer4.txt");
                    }
                    else
                    {
                        displayFileContent("kPaneer5.txt");
                    }
                }
                else if(i==3)
                {
                    filename = "knoodles.txt";
                    displayFileContent("knoodles.txt");
                    cout << "which dish would you like to eat..." << endl;
                    cout << "=========================================== ==============================" << endl;
                    if (dish == 1)
                    {
                        displayFileContent("knoodles1.txt");
                    }
                    else if (dish == 2)
                    {
                        displayFileContent("knoodles2.txt");
                    }
                    else if (dish == 3)
                    {
                        displayFileContent("knoodles3.txt");
                    }
                    else if (dish == 4)
                    {
                        displayFileContent("knoodles4.txt");
                    }
                    else if(dish==5)
                    {
                        displayFileContent("knoodles5.txt");
                    }
                    else{
                        cout<<"invalid"<<endl;
                    }               
                }
                else
                {
                    cout<<"invalid";
                } 
            }
            else if(choice==2)
            {
                cout<<"which type of sweet you would like: "<<endl<<"1.Dessert"<<endl<<"2.Rice"<<endl<<"3.Bakery";
                cin>>i;
                if(i==1)
                {
                    displayFileContent("kdessert.txt");
                    cout << "which dish would you like to eat..." << endl;
                    cout << "=========================================== ==============================" << endl;
                    if (dish == 1)
                    {
                        displayFileContent("kdessert1.txt");
                    }
                    else if (dish == 2)
                    {
                        displayFileContent("kdessert2.txt");
                    }
                    else if (dish == 3)
                    {
                        displayFileContent("kdessert3.txt");
                    }
                    else if (dish == 4)
                    {
                        displayFileContent("kdessert4.txt");
                    }
                    else if(dish==5)
                    {
                        displayFileContent("kdessert5.txt");
                    }
                    else
                    {
                        cout<<"invalid"<<endl;
                    }               

                }
                else if(i==2)
                {
                    displayFileContent("Ksrice.txt");
                    cout << "which dish would you like to eat..." << endl;
                    cout << "=========================================== ==============================" << endl;
                    if (dish == 1)
                    {
                        displayFileContent("ksrice1.txt");
                    }
                    else if (dish == 2)
                    {
                        displayFileContent("ksrice2.txt");
                    }
                    else if (dish == 3)
                    {
                        displayFileContent("ksrice3.txt");
                    }
                    else if (dish == 4)
                    {
                        displayFileContent("ksrice4.txt");
                    }
                    else if(dish==5)
                    {
                        displayFileContent("ksrice5.txt");
                    }
                    else
                    {
                        cout<<"invalid"<<endl;
                    }               

                }
                else if(i==3)
                {
                    displayFileContent("kbakery.txt");
                    cout << "which dish would you like to eat..." << endl;
                    cout << "=========================================== ==============================" << endl;
                    if (dish == 1)
                    {
                        displayFileContent("kbakery1.txt");
                    }
                    else if (dish == 2)
                    {
                        displayFileContent("kbakery2.txt");
                    }
                    else if (dish == 3)
                    {
                        displayFileContent("kbakery3.txt");
                    }
                    else if (dish == 4)
                    {
                        displayFileContent("kbakery4.txt");
                    }
                    else if(dish==5)
                    {
                        displayFileContent("kbakery5.txt");
                    }
                    else
                    {
                        cout<<"invalid"<<endl;
                    }               
                }
                else
                {
                    cout<<"invalid";
                }
            }
               
        }
        else if (type == 3)
        {
            cout << "What you want: \n1. Spicy\n2. Sweet\n";
            cin >> choice;
            if (choice == 1)
            {
                cout<<"which ingredient you like:"<<endl<<"1.Rice"<<endl<<"2.Paneer"<<endl<<"3.noodles"<<endl;
                cin>>i;
                if(i==1)
                {
                    filename = "irice.txt";
                    displayFileContent("irice.txt");
                   cout << "which dish would you like to eat..." << endl;
                    cout << "=========================================== ==============================" << endl;

                    cin >> dish;
                    if (dish == 1)
                    {
                        displayFileContent("irice1.txt");
                    }
                    else if (dish == 2)
                    {
                        displayFileContent("irice2.txt");
                    }
                    else if (dish == 3)
                    {
                        displayFileContent("irice3.txt");
                    }
                    else if (dish == 4)
                    {
                        displayFileContent("irice4.txt");
                    }
                    else if(dish==5)
                    {
                        displayFileContent("irice5.txt");
                    }
                    else{
                        cout<<"invalid input"<<endl;
                    }
                }
                else if(i==2)
                {
                    filename = "iPaneer.txt";
                    displayFileContent("iPaneer.txt");
                    cout << "which dish would you like to eat..." << endl;
                    cout << "=========================================== ==============================" << endl;
                    if (dish == 1)
                    {
                        displayFileContent("iPaneer1.txt");
                    }
                    else if (dish == 2)
                    {
                        displayFileContent("iPaneer2.txt");
                    }
                    else if (dish == 3)
                    {
                        displayFileContent("iPaneer3.txt");
                    }
                    else if (dish == 4)
                    {
                        displayFileContent("iPaneer4.txt");
                    }
                    else
                    {
                        displayFileContent("iPaneer5.txt");
                    }
                }
                else if(i==3)
                {
                    filename = "inoodles.txt";
                    displayFileContent("inoodles.txt");
                    cout << "which dish would you like to eat..." << endl;
                    cout << "=========================================== ==============================" << endl;
                    if (dish == 1)
                    {
                        displayFileContent("inoodles1.txt");
                    }
                    else if (dish == 2)
                    {
                        displayFileContent("inoodles2.txt");
                    }
                    else if (dish == 3)
                    {
                        displayFileContent("inoodles3.txt");
                    }
                    else if (dish == 4)
                    {
                        displayFileContent("inoodles4.txt");
                    }
                    else if(dish==5)
                    {
                        displayFileContent("inoodles5.txt");
                    }
                    else{
                        cout<<"invalid"<<endl;
                    }               
                }
                else
                {
                    cout<<"invalid";
                } 
            }
            else if(choice==2)
            {
                filename = "isweet.txt";
                cout<<"which type of sweet you would like: "<<endl<<"1.Dessert"<<"2.Rice"<<endl<<"3.Bakery";
                cin>>i;
                if(i==1)
                {
                    displayFileContent("idessert.txt");
                    cout << "which dish would you like to eat..." << endl;
                    cin>>dish;
                    cout << "=========================================== ==============================" << endl;
                    if (dish == 1)
                    {
                        displayFileContent("idessert1.txt");
                    }
                    else if (dish == 2)
                    {
                        displayFileContent("idessert2.txt");
                    }
                    else if (dish == 3)
                    {
                        displayFileContent("idessert3.txt");
                    }
                    else if (dish == 4)
                    {
                        displayFileContent("idessert4.txt");
                    }
                    else if(dish==5)
                    {
                        displayFileContent("idessert5.txt");
                    }
                    else
                    {
                        cout<<"invalid"<<endl;
                    }               

                }
                else if(i==2)
                {
                    displayFileContent("isrice.txt");
                    cout << "which dish would you like to eat..." << endl;
                    cout << "=========================================== ==============================" << endl;
                    if (dish == 1)
                    {
                        displayFileContent("isrice1.txt");
                    }
                    else if (dish == 2)
                    {
                        displayFileContent("isrice2.txt");
                    }
                    else if (dish == 3)
                    {
                        displayFileContent("isrice3.txt");
                    }
                    else if (dish == 4)
                    {
                        displayFileContent("isrice4.txt");
                    }
                    else if(dish==5)
                    {
                        displayFileContent("isrice5.txt");
                    }
                    else
                    {
                        cout<<"invalid"<<endl;
                    }               

                }
                else if(i==3)
                {
                    displayFileContent("ibakery.txt");
                    cout << "which dish would you like to eat..." << endl;
                    cout << "=========================================== ==============================" << endl;
                    if (dish == 1)
                    {
                        displayFileContent("ibakery1.txt");
                    }
                    else if (dish == 2)
                    {
                        displayFileContent("ibakery2.txt");
                    }
                    else if (dish == 3)
                    {
                        displayFileContent("ibakery3.txt");
                    }
                    else if (dish == 4)
                    {
                        displayFileContent("ibakery4.txt");
                    }
                    else if(dish==5)
                    {
                        displayFileContent("ibakery5.txt");
                    }
                    else
                    {
                        cout<<"invalid"<<endl;
                    }               
                }
                else
                {
                    cout<<"invalid";
                }
            }
               
        }
        else
        {
            cout << "Invalid option. Please choose 1, 2, or 3.\n";
            cout << "=========================================================================" << endl;
        }
        getFeedback(feedback);
    }
    return 0;
}